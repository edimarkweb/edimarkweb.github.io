pymupdf4llm_git_branch = 'aptest-jules'
pymupdf4llm_git_comment = 'pdf4llm/setup.py setup.py: increment version to 1.28.2.'
pymupdf4llm_git_diff = ''
pymupdf4llm_git_diff_n = None
pymupdf4llm_git_sha = '5de0c983abba8902bfe15ab0053eaecdb0fd761b'
